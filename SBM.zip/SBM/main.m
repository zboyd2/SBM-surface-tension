%% Use this file to run a single test on a single data set.
%% To run a batch of tests on possibly multiple data sets, consider using standard_benchmark.m

%%%% Common user-set parameters %%%%%
if not(exist('benchmark_flag')) || benchmark_flag == false % If I am not being called from standard_benchmark
	problem = 'PP'; % Name of the network to partition, as specified in data/get_data.m Options: LFR, karate, MS, PP. To add your own network, provide an entry in data/get_data.m.
	opts.solver='MCF'; % Options: MBO, AC, MCF
	deterministic = false; % fix the random seed for replicability
	global verbose;	verbose = true;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%%%%

tic;

addpath(genpath(pwd));

if deterministic == true
	seed=81;
	rng(seed,'twister');
	opts.seed=seed;
elseif exist('opts') && isfield(opts,'seed')
	rmfield(opts,'seed');
else
	opts.dummy = true;
end

[A,tag,opts] = get_dataset(problem,opts);

N = size(A,2);
nhat = opts.nhat;
k = full(sum(A,2));
twom = sum(k);

% Initial guess at w (omega in the paper)
w = 0.1*ones(nhat,nhat);
w = w + eye(nhat);
W = -log(w);
W_0 = W;

g = randi(nhat,N,1);

Q_before = Qcut(g,A,W);
Q_AIC_before = Q_AIC(g,A,W,opts);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[g,W,info] = recursive_splitter(A,W,nhat,opts); u = g2u(g); 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

w = exp(-W);

Q_after = Qcut(g,A,W);
Q_AIC_after = Q_AIC(g,A,W,opts);

tag_u = g2u(tag);
W_tag = W_opt(tag,A,true); %strict
Q_tag     =  Qcut(tag,A,W_tag);
Q_AIC_opt = Q_AIC(tag,A,W_tag,opts);

disp(sprintf('Initial Q: \t%.2f',Q_before));
disp(sprintf('Final Q: \t%.2f',Q_after));
disp(sprintf('Optimal Q: \t%.2f',Q_tag));
if Q_after < Q_tag - 0.00001;
	disp('This solution is better than the ground truth!')
end
disp(sprintf('relative Q: \t%.2f',(Q_after-Q_tag)/abs(Q_tag)));
disp(sprintf('Initial Q_AIC: \t%.2f',Q_AIC_before));
disp(sprintf('Final Q_AIC: \t%.2f',Q_AIC_after));
disp(sprintf('Optimal Q_AIC: \t%.2f',Q_AIC_opt));
if Q_AIC_after < Q_AIC_opt - 0.00001;
	disp('This solution is better than the ground truth!')
end

disp(sprintf('Max number of groups used: %d',info.nhat_max));

purv = purityMeas(g,tag);
nmiv = nmiMeas(g,tag);
disp(sprintf('Final classes: %d of %d',max(unique(g)),nhat));
disp(sprintf('Final Purity: \t%.2f',purv*100));
disp(sprintf('Final NMI: \t%.2f',nmiv*100));
times_ = toc;
disp(sprintf('Time: \t%.2f',times_));
