% SBM_cut aims to optimize SBM log likelihood assuming the weights are known.
% group is the assignment of each node
% W is the matrix of SBM weights
% A is the adjacency matrix
% k is the degree vector in the whole graph
% m is the number of edges in the whole graph
function group = MBO_sub(group,A,W,k,m)

	to_stop = false;
	global verbose;
	if verbose; disp('entering mbo routine'); end;

	N = length(k);
	if N==2
		group = [1 2];
		return;
	end
	nhat=size(W,1);
	iter = 30;

	% initialization
	u = g2u(group,nhat);
	[~,PreIndex] = max(u,[],2);

	sigma = W_to_sigma(W);

	nhat = size(W,2);
	eigCount = 2*nhat;
	eigCount = min(eigCount,N-1);
	if verbose; fprintf('getting %d eigs of L\n', eigCount); end;
	L = diag(sparse(k)) - A;
	opts.tol = 0.1;
	opts.issym = true;
	opts.write_A = true;
	flag = 1; flcount = 0;
	while flag==1 && flcount < 10
		[V,D,flag] = eigs(L,eigCount,'sa',opts);
		flcount = flcount + 1;
		if flag~=0
			disp('Recalculating eigs. We did not converge on the first try.');
		end
	end
	if flcount == 10
		save temp.mat;
		error('AC_sub: not all eigs converged. state saved in temp.mat');
	end
	D = diag(D);

	M1 = sqrt(1/m)*(V'*k);
	M2 = exp(-W);
	M3 = V'*k*diag(W)';

	if size(D,1) == 1
		D = D';
	end
	% check the timestep restriction:
	eigCount = size(D,1);
	M = @(x) reshape(M1*(M1'*reshape(x,[eigCount,nhat]))*M2,[eigCount*nhat,1]);
	if verbose; disp('getting largest eigenvalue of M'); end;
	lambda_max = eigs(M,eigCount*nhat,1,'LA',opts);

	dti = 1/(2*lambda_max);

	% outer timestep
	opts.lam2 = D(2);
	dt = estimate_timestep(A,W,opts);
	dt = 8*dt; 

	% main iteration
	j = 1;
	while j < iter
		if verbose; disp(sprintf('in MBO, outer loop iteration %d',j)); end;

		if exist('V')
			u = MBO_diffuse(u,dt,M1,M2,M3,V,D,dti); %Pseudospectral
		else
			u = MBO_diffuse(u,dt,A,W); %Spacial
		end

		[u,Index] = threshold(u,PreIndex,sigma);
		MBO_stopping;
		if to_stop == true; break; end;

	end

	if j==iter
		warning('MBO did not converge'); 
	end
	[~,~,group]=unique(Index);
