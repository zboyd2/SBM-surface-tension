%Stopping Criterion -- try more frequent thresholding if you get stuck
global verbose
if verbose; disp(sprintf('stopping: nodes changed: %d',nnz(PreIndex - Index))); end
if norm(PreIndex-Index)/norm(Index)<.001 || mod(j,100)==0
		to_stop = true;
else
	PreIndex = Index;
end;
j = j+1;
