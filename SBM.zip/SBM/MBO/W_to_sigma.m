% use sigma instead of W
function sigma = W_to_sigma(W);
	nhat = size(W,2);
	sigma = zeros(nhat,nhat);
	sig_min = 100000;
	for a=1:nhat
		for b=1:nhat
			sigma(a,b) = W(a,b) - 0.5*W(a,a) - 0.5*W(b,b);

			if (a ~=b) &&(sigma(a,b) < sig_min)
				sig_min = sigma(a,b);
			end
		end
	end
	if sig_min <= 0 % I do not know if this can happen
		warning('W_to_sigma: nonpositive sigmas encountered');
	end

