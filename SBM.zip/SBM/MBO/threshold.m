%MBO thresholding:
function [u,Index] = threshold(u, PreIndex, sigma)
	u_old_old = u;
	N = size(u,1);
	nhat = size(u,2);

	u = u*sigma;
	for i=1:N

		[a,b] = min(u(i,:));

%		% These commented lines use tie breaking by randomly selecting, if you are worried about the bias of always picking the first one
%		iind=find(u(i,:)==a);
%		qq=randi(length(iind),1,1);
%		b = iind(qq);

		u(i,:) = 0;
		u(i,b) = 1;
	end
	[~,Index] = max(u,[],2);
	[~,~,in] = unique(Index);
end
