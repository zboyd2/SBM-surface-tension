function dt = estimate_timestep(A,W,opts)

	global verbose;
	if verbose; disp('estimating timestep'); end;

	if nargin < 3
		opts.write_A = false;
	end

	k = full(sum(A,2));
	m = sum(k)/2;
	N = size(A,2);
	nhat = size(W,2);

	L = spdiags(k,0,N,N) - A;

	if nargin ==3 && isfield(opts,'lam2')
		D = [0; opts.lam2];
	else
		opts.tol = 0.001;
		if verbose; disp('getting the two smallest eigenvalues of L'); end;
		[~,D] = eigs(L,2,'sa',opts);
	end
	d = eig(W);
	d = diag(d);
	d = -min(d,0);
	tol = 10^(-7);

	lambda_min = min(min(D(D>tol)))*min(min(d(d>tol)));

	if verbose; disp('getting the largest eigenvalue of L'); end;
	D = eigs(L,1);

	lambda_max = max(max(D(D>tol)))*max(max(d(d>tol)));

	d = eig(exp(-W));
	d = diag(d);
	d = max(d,0);

	lambda_max = lambda_max + max(max(d(d>tol)))*norm(k)/m;
	lambda_min = lambda_min;

	dt = 1/sqrt(lambda_min*lambda_max);
