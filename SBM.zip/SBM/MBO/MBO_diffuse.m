% Solve the heat equation with SBM MBO forcing term with initial data u up to time dt. Two modes:
% pseudospectral mode and spacial mode
% In pseudospectral mode, we assume the following formulas hold
% M1 = sqrt(1/m)*(V'*k);
% M2 = e^(-W);
% In spacial mode, we assume the following:
% M1 is the graph adjacency matrix
% M2 is W, the SMB weights
% 
function u = MBO_diffuse(u,dt,M1,M2, M3,V,D,dti)

	dt = dt/2;

	if nargin > 4

		if min(size(D))>1
			D = diag(D);
		end

		niter = round(dt / dti);
		if niter < 4
			niter = 4;
			dti = dt/4;
		end
	
		M1 = dti*M1;
		M3 = dti*M3;
		eigCount = size(D,1);
		M4 = spdiags(exp(-dti*D),0,eigCount,eigCount);

		nhat = size(u,2);

		a = V'*u;
		for iter=1:niter
			a = M4*a;
			a = a - M1*(M1'*a)*M2 - M3;
		end
		u = V*a;
	else

		A = M1;
		N = size(A,2);
		k = full(sum(A,2));
		twom = sum(k);
		m = twom/2;
		L = diag(k) - A;

		W = M2;
		nhat = size(W,1);
	
		% check the timestep restriction:
		M = @(x) reshape((1/m)*k*(k'*reshape(x,[N,nhat]))*exp(-W),[N*nhat,1]);
		lambda_max = eigs(M,N*nhat,1);

		dti = 1/(2*lambda_max);
		niter = round(dt / dti);
		if niter < 4
			niter = 4;
			dti = dt/4;
		end
		global verbose
		if verbose; disp(sprintf('diffuse: niter is %d and inner timestep is %d',niter,dti)); end

		if verbose; disp('niter'); end
		niter
		for iter=1:niter
			iter
			u = (speye(N)+dti*L) \ (u - (dti/m)*k*(k'*u)*exp(-W) - dti*k*diag(W)'); % The diag term is meant to compensate for using sigma later. If W(a,a) is really big, that means that Cut(a,a)=0, which is possible, but unlikely.
		end
%		if max(diag(W)) > 1
%			warning('diffuse: large diagonal on W may cause unknown effects');
%			diag(W)
%		end

	end
end
