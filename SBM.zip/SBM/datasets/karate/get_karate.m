function [A,tag] = get_karate()

	fileID =fopen(sprintf('%s/../karate/karate.dat',pwd));
	formatspec = '%f';
	sizeA = [2 Inf];
	edges = fscanf(fileID,formatspec,sizeA);
	edges = edges';
	fclose(fileID);

	N=34;
	A = zeros(N,N);
	for i=1:size(edges,1)
		A(edges(i,1),edges(i,2)) = 1;
		A(edges(i,2),edges(i,1)) = 1;
	end

	tag = ones(N,1);
	inds = [10 15 16 21 19];
	tag(inds) = 2;
	tag(23:34) = 2;

end
