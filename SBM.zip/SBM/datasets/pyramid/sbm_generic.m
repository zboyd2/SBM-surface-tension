function A = sbm_generic(W,tag)

	N = length(tag);
	nhat = size(W,1);
	A = zeros(N,N);

	for a=1:nhat
		inda = find(tag==a);
		for b=a:nhat
			indb = find(tag==b);
			A(inda,indb) = W(a,b);
		end
	end

	A = poissrnd(A,N,N);

	A = max(A,A');

