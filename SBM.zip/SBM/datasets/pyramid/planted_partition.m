% Constructs a sparse pyramid graph with at most N nodes
function [A,g,N] = planted_partition(N)

	% Determine the size of the overall graph
	N_min = 100;
	N_cur = N_min;
	N_tot = 0;
	while N_tot < N
		N_tot = N_tot + N_cur;
		%N_cur = N_cur*2;
	end
	%N_max = N_cur/2;
	N = N_tot;

	% Make the graph
	A = sparse([],[],[],N,N,11*N);
	N_cur = N_min;
	N_tot = 0;
	count = 1;
	while N_tot < N

		ind = (N_cur*(count-1) +1 :N_cur*count) + 1;

		if N_cur > 40 % Was 100, but it made the spectrum weird because some nodes are high-degree
			A(ind,ind) = (sprandsym(N_cur,(40/N_cur)) ~= 0); % 20 is the mean number of edges
		else
			A(ind,ind) = 1;
		end
		for i=ind
			A(i,i) = 0;
		end

		ind_temp = 1:N_cur;
		for i=1:count -1
			A(ind_temp,ind) = (sprand(N_cur,N_cur,1/N_cur) > 0);
			ind_temp = ind_temp + N_cur;
		end

		%temp = 2*N_cur-N_min;
		%if temp < N
			%A(temp,temp+1) = 1;
			%A(temp+1,temp) = 1;
		%end

		g(ind) = count;
		count = count + 1;

		%N_cur = N_cur * 2;
		N_tot = N_tot + N_cur;

		ind_old = ind;
	end

	A = max(A,A');
