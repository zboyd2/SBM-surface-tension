% Constructs a pyramid graph with at most N nodes
function [A,g,N,N_max] = pyramid(N)

	% Determine the size of the overall graph
	N_min = 10;
	N_cur = N_min;
	N_tot = 0;
	while N_tot < N
		N_tot = N_tot + N_cur;
		N_cur = N_cur*2;
	end
	N_max = N_cur/2;
	N = N_tot;

	% Make the graph
	A = zeros(N,N);
	N_cur = N_min;
	N_tot = 0;
	count = 1;
	while N_tot < N

		ind = (N_cur:(2*N_cur-1)) - N_min + 1;

		A(ind,ind) = 1;
		for i=ind
			A(i,i) = 0;
		end

		temp = 2*N_cur-N_min;
		if temp < N
			A(temp,temp+1) = 1;
			A(temp+1,temp) = 1;
		end

		g(ind) = count;
		count = count + 1;

		N_cur = N_cur * 2;
		N_tot = N_tot + N_cur;
	end
