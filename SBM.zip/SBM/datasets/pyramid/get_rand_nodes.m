
function v = get_rand_nodes(p,ns)

		nn = length(p);
		c = cumsum(p);
		v = rand(ns,1);
		v = ceil(interp1(c,1:nn,v));
		v(isna(v)) = 1;
		v(v==(nn+1)) = nn;

end
