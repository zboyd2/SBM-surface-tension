function [A,w,tag] = degree_corrected_sbm(N,nhat,lambda)

	tag = ceil( (1:N)/N * nhat );

	k = power_sample(N);

	twom = sum(k);

	kap = zeros(nhat,1);
	for a=1:nhat
		kap(a) = sum(k(tag==a));
	end

	theta = k;
	for a=1:nhat
		theta(tag==a) = theta(tag==a)/kap(a);
	end

	w_rand = kap*kap'/twom;
	w_plant = diag(kap);

	w = lambda*w_rand + (1-lambda)*w_plant; % sum_{i\in a, j\in b} A_{i,j}

	n_edges = w - 0.5*diag(diag(w));
	%n_edges = poissrnd(n_edges,nhat,nhat); % Described in Newman and Karrer, but it seems unnecessary

	indas = [];
	indbs = [];
	for a=1:nhat
		for b=a:nhat
			x = find(tag==a);
			inda = x(get_rand_nodes(theta(tag==a),n_edges(a,b))); % random indices from a

			x = find(tag==b);
			indb = x(get_rand_nodes(theta(tag==b),n_edges(a,b))); % random indices from b

			indas = [indas inda];
			indbs = [indbs indb];
		end
	end
	A = sparse(indas, indbs, ones(length(indas),1),N,N,2*length(indas));

	A = max(A,A');

	% Minor adjustments.
	A = A - diag(diag(A));
	A = (A~=0);
	A = double(A);

	% normalization to match with Newman
	k = sum(A,2);
	twom = sum(k);
	kap = zeros(nhat,1);
	for a=1:nhat
		kap(a) = sum(k(tag==a));
	end
	w = w ./ (kap*kap')*twom;

end

function v = get_rand_nodes(p,ns)

	ns = ceil(ns);

	nn = length(p);
	c = cumsum(p);
	v = rand(ns,1);
	v = ceil(interp1(c,1:nn,v));
	%v(isna(v)) = 1; % only works in octave
	v(isnan(v)) = 1;
	v(v==(nn+1)) = nn;

end

function v = power_sample(N)

	a = 20; % min degree
	b = 80; % max degree
	r = 2; % power law exponent

	c = (r-1) / (a^(1-r) - b^(1-r)); % normalizing constant

	v = rand(N,1);

	v = (a^(1-r) - (r-1)/c*v).^(1/(1-r)); % Inverse of power law CDF
end
