function make_data(params)

	[pathstr,~,~,] = fileparts(mfilename('fullpath'));
	olddir = cd(pathstr);

	% Select defaults if variables are not already defined
	if isfield(params,'N') == false
		params.N = 1000;
	end
	if isfield(params,'k_av') == false
		params.k_av = 20;
	end
	if isfield(params,'k_max') == false
		params.k_max = 50;
	end
	if isfield(params,'k_exp') == false
		params.k_exp = 2;
	end
	if isfield(params,'com_exp') == false
		params.com_exp = 1;
	end
	if isfield(params,'mix') == false
		params.mix = 1;
	end
	if isfield(params,'com_min') == false
		params.com_min = 10;
	end
	if isfield(params,'com_max') == false
		params.com_max = 50;
	end
	if isfield(params,'use_min_max') == false
		params.use_min_max = true;
	end

	% Change the mixing parameter in parameters.dat.
	% Read txt into cell A
	fid = fopen('parameters.dat','r');
	i = 1;
	count = 1;
	ind = zeros(8,1); % Eight parameters in the file
	tline = fgetl(fid);
	while ischar(tline)
		A{i} = tline;
		if ~isempty(tline) && tline(1) ~= '#'
			ind(count) = i;
			count = count + 1;
		end
		i = i+1;
		tline = fgetl(fid);
	end
	fclose(fid);

	% Change cell A
	A{ind(1)} = sprintf('%d\t# number of nodes',params.N);
	A{ind(2)} = sprintf('%d\t# average degree',params.k_av);
	A{ind(3)} = sprintf('%d\t# maximum degree',params.k_max);
	A{ind(4)} = sprintf('%d\t# exponent for the degree distribution',params.k_exp);
	A{ind(5)} = sprintf('%d\t# exponent for the community size distribution',params.com_exp);
	A{ind(6)} = sprintf('0.%d\t# mixing parameter',params.mix);
	if params.use_min_max == true
		A{ind(6)+1} = sprintf('%d\t# minimum for community sizes',params.com_min);
		A{ind(6)+2} = sprintf('%d\t# maximum for the community sizes',params.com_max);
	else
		A{ind(6)+1} = sprintf('#10\t# minimum for community sizes');
		A{ind(6)+2} = sprintf('#50\t# maximum for the community sizes');
	end

	% Write cell A into txt
	fid = fopen('parameters.dat', 'w');
	for i = 1:numel(A)
		fprintf(fid,'%s\n', A{i});
	end
	fclose(fid);

	if isfield(params,'seed') == true

		fid = fopen('bench_seed.dat','w');
		fprintf(fid,'%d',params.seed);
		fclose(fid);

	end

	system('./benchmark');

	cd(olddir);

