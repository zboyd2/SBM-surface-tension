function [W,tag]=lfr_getdata(N)

	[pathstr,~,~,] = fileparts(mfilename('fullpath'));
	olddir = cd(pathstr);

	if nargin == 0
		warning('getdata: you have to supply the number of nodes now');
	end

	fileID = fopen('network.dat','r');
	formatspec='%d\t%d'; sizeA=[2 Inf];
	A=fscanf(fileID,formatspec,sizeA);
	A=A';

	W=zeros(N);
	for i=1:size(A,1)
		W(A(i,1),A(i,2))=1; 
	end
	W=sparse(W);



	fileID = fopen('community.dat','r');
	A=fscanf(fileID,formatspec,sizeA);
	A=A';

	tag=zeros(N,1);
	for i=1:N
		tag(i)=A(i,2); 
	end

	cd(olddir);
