function [A,tag,opts] = get_dataset(str,opts);

	switch str
		case 'LFR'

			%opts.N = 200;opts.k_av = 5;opts.k_max = 10;opts.use_min_max = false; opts.lam = 0.1;
			opts.N = 1000;opts.k_av = 20;opts.k_max = 50; opts.lam = 0.001;
			N = opts.N;
			make_data(opts);
			[A,tag]=lfr_getdata(N);
			[A,tag] = get_giant_component(A,tag);
			N = size(A,2);
			nhat = max(tag);
			opts.nhat = nhat;

		case 'karate'

			[A,tag] = get_karate();
			N = 34;
			nhat = 2;
			opts.lam = 1;
			opts.nhat = 2;

		case 'MS'

			N = 10000;
			[A,tag,~] = pyramid(N);
			[A,tag] = get_giant_component(A,tag);
			N = size(A,2);
			nhat = max(tag);
			opts.nhat = nhat;
			opts.lam = 0.1;

		case 'PP'

			N = 16000; opts.lam = 0.001; nhat = 10;
			%N = 16000; opts.lam = 0.1; nhat = 3;
			lambda = 0.1;
			[A,w,tag] = degree_corrected_sbm(N,nhat,lambda);
			w_gt = w;
			opts.nhat = nhat;
			
		case 'Caltech'
			load Caltech36; 
			nhat=8; % A, expected to have the community structure of houses

			N = size(A,2);
			tag = local_info(:,5);
			[~,~,tag] = unique(tag);
			[A,tag,ind] = get_giant_component(A,tag);
			N = size(A,2);
			opts.node_attributes = local_info(ind,:);
			opts.nhat = nhat;
			opts.lam = 0.13;
		case 'Princeton'
			load Princeton12; 
			nhat=4; % A, expected to have the community structure of years

			N = size(A,2);
			tag = local_info(:,6);
			[~,~,tag] = unique(tag);
			[A,tag,ind] = get_giant_component(A,tag);
			N = size(A,2);
			opts.node_attributes = local_info(ind,:);
			opts.nhat = nhat;
			opts.lam = 0.13;
		case 'Penn'
			load Penn94; 
			nhat=8; % A

			N = size(A,2);
			tag = local_info(:,6);
			[~,~,tag] = unique(tag);
			[A,tag,ind] = get_giant_component(A,tag);
			N = size(A,2);
			opts.node_attributes = local_info(ind,:);
			opts.nhat = nhat;
			opts.lam = 0.13;
		case 'urban'
			load W_3_10;
			nhat = 5;
			tag = ones(size(W,2),1);
			[A,tag,ind]=get_giant_component(W,tag);
			N = size(A,2);
			opts.lam = 0.13;
			opts.nhat=nhat;
			opts.ind = ind;
		case 'plumes'
			load W_7_3;
			nhat = 5;
			tag = ones(size(W,2),1);
			[A,tag,ind]=get_giant_component(W,tag);
			N = size(A,2);
			opts.lam = 0.13;
			opts.nhat=nhat;
			opts.ind = ind;
		otherwise
			error('invalid dataset name')
	end
