% Runs each method a specified number of times on each problem

benchmark_flag = true; % lets main.m know it is being called from another script
sb_iter_max=2; % how many times to run each test
global verbose; verbose=false;

problem_list = {'PP','MS','LFR'}; % Networks to partition
solver_list = {'MCF','AC','MBO'}; % Methods to try

for problem_singleton = problem_list
	for solver = solver_list
		for sb_iter = 1:sb_iter_max
			problem = problem_singleton{1};
			opts.solver = solver{1};
			fprintf('\nSolving %s with %s, iteration %d\n',problem,opts.solver,sb_iter)
			main
%			if nmiv > 1 - 0.001 ||  Q_AIC_after < Q_AIC_opt - 0.00001; % Uncomment if you want to stop at the first success
%				break;
%			end
		end
	end
end

clear benchmark_flag
