function Q = Qcut(g,A,W,Cut,vol)

	nhat = size(W,2);
	u = g2u(g,nhat); % the nhat is important in this case

	if size(u,2) > size(W,1)
		save temp.mat
		error('W did not grow with u--u is too wide! Results saved in temp.mat')
	end

	k = full(sum(A,2));
	twom = sum(k);

	if nargin == 3
		Cut = u'*A*u;
		vol = k'*u;
	end

	eW = exp(-W);
	W(Cut==0) = 0; % Fixes a 0*Inf issue

	Q = sum(sum(W.*Cut)) + (1/twom)*sum(sum(eW.*(vol'*vol)));

end
