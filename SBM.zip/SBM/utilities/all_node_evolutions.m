% Used in AC evolution verbose mode. Useful for seeing the thickness of the transition layer among other things.
load temp_AC_data
ninds = min(size(A,1),200); % Number of nodes to sample
inds = randi(size(A,1),1,ninds); % Nodes to sample
ntime = length(to_save);

to_plot = zeros(ntime,ninds); % Will hold the values of the sampled nodes at each time
for i=1:ntime
	tmp = to_save{i}; % Get all node values at time i
	to_plot(i,:) = tmp(inds,1); % Put the sampled node values in to_plot
end

plot(to_plot)
