function Q = Q_AIC(g,A,W,opts,Cut,vol)

	if nargin < 5
		Q = Qcut(g,A,W);
	else
		Q = Qcut(g,A,W,Cut,vol);
	end

	nhat = size(W,2);

	if nargin < 4 || isfield(opts,'nhat') == false % Use AIC if prior is not provided.
		Q = Q + nhat^2;
		return;
	else
		nhat_opt = opts.nhat;
	end

	if isfield(opts,'lam') == false
		lam = 0.1;
	else
		lam = opts.lam;
	end

	Q = Q + lam*abs(Q)*(nhat - nhat_opt)^2;

end
