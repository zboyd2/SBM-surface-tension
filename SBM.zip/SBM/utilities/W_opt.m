function W = W_opt(g,A,strict,Cut,vol)

	u = g2u(g);
	u = sparse(u); % Speeds up matrix mulitiplies later

	if nargin < 3
		strict = false;
	end

	k = full(sum(A,2));
	twom = sum(k);
	nhat = size(u,2);

	% W update
	if nargin < 4
		vol = full(k'*u); % strictly positive (hopefully...)
		Cut = full(u'*A*u);
	end
	
	W = zeros(nhat,nhat);

	tol = 10^(-7);
	vv = vol'*vol;
	iind = ((vol'*vol).*Cut) > tol;
	W(iind) = log(vv(iind)./(twom*Cut(iind))); 
	W_max = max(max(W));
	W(Cut < tol) = 1.1*abs(W_max);

	if strict == false
		W(Cut < tol) = 1.1*abs(W_max);% This rule does not work on disjoint cliques, since then W is uniform
	else
		W(Cut < tol) = Inf;
	end

end
