% does changing the assignment of any single node improve the score?
function retval = is_fixed_point(g,W,A,opts)

	% Check if changing a single node can improve anything.
	Q_old = Q_AIC(g,A,W,opts);
	N = size(A,2);
	nhat=size(W,2);
	tol = 10^(-5);
	g_temp=g;
	W_temp=W;
	for i=1:N
		for a=1:nhat
			if a~=g(i)
				g_temp(i) = a;
				W_temp = W_opt(g_temp,A);
				Q_temp = Q_AIC(g_temp,A,W_temp,opts);

				if Q_temp < Q_old - tol
					fprintf('Node %d can be safely moved to class %d\n',i,a)
					W_temp
					retval = false;
					return;
				end
			end
		end
	end

	disp('No single-node moves will improve the objective.')
	retval=true;
