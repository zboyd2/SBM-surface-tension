function pur=purityMeas(g,tag)
	
	%cleaning
	if size(g,1)<size(g,2)
		g=g';
	end
	if size(tag,1)<size(tag,2)
		tag=tag';
	end
	[~,~,g]=unique(g);
	[~,~,tag]=unique(tag);

	N = length(g);
	nhat = max(g);

	pur = 0;
	for i = 1:nhat
		index = find(g == i);
		mmax = max(hist(tag(index), 1:max(tag)));
		pur = pur + mmax;
	end
	pur=pur/N;
end
