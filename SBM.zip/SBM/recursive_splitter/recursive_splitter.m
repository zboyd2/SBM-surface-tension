% This function used to serve its own purpose but now essentially just calls split.m
% 
% A:  weight matrix
% W: SBM weights
% n_given: max number of clusters at each sub-partition step. (One can choose n=10)
% Output g: group assignments

function [g,W,info] = recursive_splitter(A,W,n_given, opts)
	global verbose

	N = size(A,2);
	g = ones(N,1);
	W = 1;

	info.nhat_max = 1;

	tol = 0.01;
	sims = -1;
	i = 1;
	cmin = 1;
	W_old = W;
	to_cont = true;
	to_split = true;
	while to_cont == true

		g_old = g;
		W_old = W;

		to_split = ones(max(g),1)' == 1;
		[g,W] = split(A,W,n_given,g,opts,to_split);

		if info.nhat_max < size(W,2)
			info.nhat_max = size(W,2);
		end

		g_old_ = g;

		changes(i) = nmiMeas(g,g_old);
		i = i+1;

		sims = nnz(g-g_old_);
		if verbose; disp(sprintf('sims %f',sims)); end

		if sims == 0
			to_cont = false;
		end

	end

	if length(changes) > 1
		changes(2:end);
	end

	info.nonstrict_W=W;
	W = W_opt(g,A,true); %strict
end
