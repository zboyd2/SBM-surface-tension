function [Cut,vol,W,Q] = Qmerge(Cut_old,vol_old,ahat,bhat,twom,opts)

	% Make sure bhat > ahat
	if bhat<ahat
		t = ahat;
		ahat = bhat;
		bhat = t;
	end

	nhat = size(Cut_old,2); %nhat is the size of the OLD partition

	ind = [1:bhat-1 bhat+1:nhat]; % Everything except bhat

	vol = vol_old(ind);
	vol(ahat) = vol(ahat) + vol_old(bhat);

	Cut = Cut_old(ind,ind);
	Cut(:,ahat) = Cut_old(ind,ahat)  + Cut_old(ind,bhat);
	Cut(ahat,:) = Cut_old(ind,ahat)' + Cut_old(ind,bhat)';
	Cut(ahat,ahat) = Cut_old(ahat,ahat) + Cut_old(bhat,bhat) + 2*Cut_old(ahat,bhat);

	W = zeros(nhat-1,nhat-1);

	tol = 10^(-7);
	vv = vol'*vol;
	iind = ((vol'*vol).*Cut) > tol;
	W(iind) = log(vv(iind)./(twom*Cut(iind))); 
	W_max = max(max(W));
	W(Cut < tol) = 1.1*abs(W_max);

	strict=false;
	if strict == false
		W(Cut < tol) = 1.1*abs(W_max);% This rule does not work on disjoint cliques, since then W is uniform
	else
		W(Cut < tol) = Inf;
	end

	eW = exp(-W);
	WW = W;
	W(Cut==0) = 0; % Fixes a 0*Inf issue

	Q = sum(sum(W.*Cut)) + (1/twom)*sum(sum(eW.*(vol'*vol)));

	nhat = size(W,2);

	if nargin < 4 || isfield(opts,'nhat') == false % Use AIC if no prior is provided.
		Q = Q + nhat^2;
		return;
	else
		nhat_opt = opts.nhat;
	end

	if isfield(opts,'lam') == false
		lam = 0.1;
	else
		lam = opts.lam;
	end

	Q = Q + lam*abs(Q)*(nhat - nhat_opt)^2;

	W = WW; %Undo the zeroing out of some elements earlier
