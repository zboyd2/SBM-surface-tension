% vectorized version of the code in http://ufdc.ufl.edu/IR00000353/00001/
function x = projsplx_vec(y)

nhat = size(y,2);
N = size(y,1);

s = sort(y,2,'descend');
tmpsum = zeros(N,1);
nbget = true(N,1);
tmax = zeros(N,1);

for ii = 1:nhat-1
    tmpsum(nbget) = tmpsum(nbget) + s(nbget,ii);
    tmax(nbget) = (tmpsum(nbget) - 1)/ii;

    nbget(tmax >= s(:,ii+1)) = false;

end
    
tmax(nbget) = (tmpsum(nbget) + s(nbget,nhat) -1)/nhat;

x = max(y-tmax*ones(1,nhat),zeros(N,nhat));

return;
