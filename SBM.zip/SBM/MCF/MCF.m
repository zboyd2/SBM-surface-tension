function g = MCF(g,A,W)
	global verbose;
	if verbose; disp('entering MCF_new'); end;

	W(W==Inf) = 2*max(max(W)); % An expediency
	twom = full(sum(sum(A)));
	N = length(g);
	nhat = max(g);
	eW = exp(-W);
	k = full(sum(A,2)); % To work on subgraphs, we should pass in the degrees and twom explicitly...
	u = g2u(g);

	converged = false;
	count = 1;
	g_old = zeros(size(g));
	while ~converged

		g_old_old = g_old; % Prevents two-cycles
		g_old = g;
		u = g2u(g,nhat);
		count = count + 1;

		NNbrs = A*u; 
		vol_old = k'*u;

		Qdiffs = zeros(N,nhat);

		for a_old=1:nhat

			% Set up
			inda_old = find(g==a_old); % the set of nodes the are currently at a

			for a=1:nhat
				ind = true(nhat,1);
				ind(a) = false;
				ind(a_old) = false;

				M = @(NNbrs) 2*NNbrs(inda_old,ind)*W(ind,a) ... %Cuts
					- 2*NNbrs(inda_old,ind)*W(ind,a_old) ...
					+ 2*NNbrs(inda_old,a)*W(a,a) ...
					- 2*NNbrs(inda_old,a)*W(a,a_old) + 2*NNbrs(inda_old, a_old)*W(a,a_old) ...
					- 2*NNbrs(inda_old,a_old)*W(a_old,a_old) ... 
					+ (1/twom)*(  2*k(inda_old)*vol_old*(eW(:,a) - eW(:,a_old))... % vols
					+ k(inda_old).^2*( eW(a,a) + eW(a_old,a_old) - 2*eW(a,a_old) )  );

				Qdiffs(inda_old,a) = M(NNbrs);
			end

		end

		[~,g] = min(Qdiffs,[],2);
		% These commented lines use tie breaking by randomly selecting, if you are worried about the bias of always picking the first one
		[z,g] = min(Qdiffs,[],2);
		for ii=1:N
			iind=find(Qdiffs(ii,:)==z(ii));
			qq=randi(length(iind),1,1);
			g(ii) = iind(qq);
		end

		converged = min(nnz(g-g_old),nnz(g-g_old_old)) == 0;
	end
end
