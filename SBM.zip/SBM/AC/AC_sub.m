% SBM_cut aims to optimize SBM log likelihood assuming the weights are known.
% group is the assignment of each node
% W is the -log of the matrix of SBM weights
% A is the adjacency matrix
% m is the number of edges
% V is eigenvectors of the laplacian
% D is the corresponding eigenvalues
function group = AC_sub(group,A,W,k,m,V,D)

	% initializations
	to_stop = false;
	N = length(k);
	nhat=size(W,1);
	if N == 1
		return;
	end
	u = g2u(group,nhat);
	[~,PreIndex] = max(u,[],2);
	sigma = W_to_sigma(W);
	global verbose

	% Get the timestep
	M = @(x) reshape((1/m)*k*(k'*reshape(x,[N,nhat]))*exp(-W),[N*nhat,1]); % This part can be eliminated, since the spectrum can be found in closed form
	lambda_max = eigs(M,N*nhat,1);
	dti = 1/(2*lambda_max);

	% Set epsilon and C
	epsilon = 0.004; % For everything but karate.
	C = 2/epsilon;

	slist = {'pseudospectral','implicit inverse','implicit backslash','explicit'};
	scheme = slist{1};
	switch scheme
		case 'pseudospectral'
			oiter = 1000;
			dti = 0.1; % Unconditionally stable (except possibly forcing terms)
			% Get eigenvectors if needed
			if ~exist('V')
				L = spdiags(k,0,N,N) - A;
				eigCount = 2*nhat;
				eigCount = min(eigCount,N-1);
				opts.tol = 0.1;
				flag = 1; flcount = 0;
				while flag==1 && flcount < 10
					[V,D,flag] = eigs(L,eigCount,'sa',opts);
					flcount = flcount + 1;
					if flag~=0
						disp('Recalculating eigs. We did not converge on the first try.');
					end
				end
				if flcount == 10
					save temp.mat;
					error('AC_sub: not all eigs converged. state saved in temp.mat');
				end
				D = diag(D);
			end
			[v,d] = eig(sigma);
			d = diag(d);
			d = min(d,0);
		case 'implicit inverse'
			% warning('using slow implicit method')
			oiter = 1000;
			disp('AC: getting LL matrix');
			dti = 0.1 % Unconditionally stable (except possibly forcing terms)
			L = diag(sparse(k)) - A;
			M = @(x) (1+C*dti) + reshape(L*reshape(x,[N,nhat])*sigma,[N*nhat,1]);
			LL = zeros(N*nhat);
			for i = 1:N*nhat
				temp = zeros(N*nhat,1);
				temp(i) = 1;
				LL(:,i) = M(temp);
			end

			disp('AC: getting the inverse');
			invLL = inv((1+C*dti)*speye(N*nhat) - dti*LL); %%% Note the sign
		case 'implicit backslash'
			oiter = 1000;
			dti = 0.1;
			L = spdiags(k,0,N,N) - A;
			M = @(x) (1+C*dti)*x + reshape( + L*reshape(x,[N,nhat])*sigma,[N*nhat,1]);
			LL = sparse(N*nhat,N*nhat);
			for i = 1:N*nhat
				temp = zeros(N*nhat,1);
				temp(i) = 1;
				LL(:,i) = M(temp);
			end

		case 'explicit'
			oiter = 1000000;
			dti = 1/(1/dti + 1/epsilon); % Issues if epsilon is Inf
			dti = dti/2; % To be safe.
			L = spdiags(k,0,N,N) - A;
			opts.tol = 0.01;
			llam = eigs(L,1,'la',opts);
			llam = llam(1);
			%disp(llam)
			dti = 1/(1/dti + 1/epsilon + llam); % Issues if epsilon is Inf
	end

	% main iteration
	j = 1;
	km = k/m;
	eW = exp(-W);
	kW = k*diag(W)';
	u_old = u;
	to_save{1} = u;
	while not(to_stop)

		% %%%%%%%%%%%%%%%%%%%%
		% Preparing the multiwell term
		% %%%%%%%%%%%%%%%%%%%%

		% Computes the matrix whos i,alpha entry is (1/2)*||u_i - e_alpha||_1
		% The first term just puts ||u_i||_1 in each entry.
		% The last two terms adjust for the fact that the e_alpha terms is included.
		nrms = sum(abs(u),2)*ones(1,nhat) - abs(u) + abs(u-1);
		nrms = nrms/2;

		% The product terms
		prods = prod(nrms,2).^2;
		prods = prods*ones(1,nhat); % Copy the vector nhat times
		nrms(nrms < 0.00000001) = Inf;% Fixes a divide by zero issue in the next line.
		prods = prods./nrms; % divide through by the particular L_1 norms
		clear nrms; % nrms was broken two lines ago and should not be used later.

		% Finally, we compute T
		T = sum(prods,2)*ones(1,nhat);
		T = T - 2*prods;

		% %%%%%%%%%%%%%%%%%%%%
		% Update u the multiwell term
		% %%%%%%%%%%%%%%%%%%%%

		switch scheme
			case 'pseudospectral'
				u = (1+C*dti)*u    + dti*(-T/(2*epsilon) - km*(k'*u)*eW - kW); % We could also treat the other coupled term implicitly
				b = V'*u*v;
				b = b ./ (1 + C*dti - dti*D*d');
				u = V*b*v';
			case 'implicit inverse'
				u = (1+C*dti)*u + dti*(- T/(2*epsilon) - km*(k'*u)*eW - kW); 
				u = reshape(invLL*reshape(u,[N*nhat,1]),[N,nhat]);
			case 'implicit backslash'
				u = (1+C*dti)*u + dti*(- T/(2*epsilon) - km*(k'*u)*eW - kW); 
				u = reshape(LL \ reshape(u,[N*nhat,1]),[N,nhat]);
			case 'explicit'
				u = u + dti*(L*u*sigma - T/(2*epsilon) - km*(k'*u)*eW - kW);
		end

		u = projsplx_vec(u);

		tt = 1000;
		if verbose && mod(j,tt)==0; plot_evolution; end; % Plotting for debugging use
		if verbose && mod(j,tt)==0; to_save{j/tt} = u; end;
		if verbose; disp(u(1,:)); end; % Numerical printout to supplement the plotting
		if j>0 && mod(j,round(0.8/dti)) == 0 % Every so often, check the stopping condition
			[~,Index] = max(u,[],2);
			stopping;
			if to_stop == true; break; end;
			u_old = u;
		end

		j = j+1;
		if verbose; fprintf('%d %d\n',j,dti*j); end;

		if j==oiter
			to_stop=true;
		end

	end

	if j==oiter
		warning('AC did not converge'); 
		j
		oiter
	end

	[~,group] = max(u,[],2);
	if verbose; save temp_AC_data.mat; end;
	if verbose; all_node_evolutions; end;
