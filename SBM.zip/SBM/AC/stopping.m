%Stopping Criterion -- try more frequent thresholding if you get stuck
if norm(PreIndex-Index)/norm(Index)<.001 || nnz(PreIndex - Index) < 0.002*length(Index)
	to_stop = true;
else
	PreIndex = Index;
end;
if j == oiter
	to_stop = true;
end
